library(reader)
library(rms)
data <- read.csv("d:/data/IN.csv", header=TRUE, sep=",")
dd=datadist(data)
options(datadist="dd")
fit <- lrm(GBC~Age+Size+Course+CEA+CA199,data=data,x=T,y=T)
nom <- nomogram(fit, fun=plogis, lp=F, funlabel="Risk")

plot(nom,
     
     label.every = 1,
     
     col.conf = c('red','green'),
     
     conf.space = c(0.1,0.5),
     
     col.grid = gray(c(0.8,0.95)),
     
     which='shock')

fit
cal<-calibrate(fit,method='boot',B=1000)
plot(cal,xlim=c(0,1),ylim=c(0,1),xlab="Predicted Probability",ylab="Observed Probability",subtitles=FALSE)
cal

library(nomogramFormula)
option <- options(datadist = "dd")
options(option)
results <- formula_rd(nomogram = nom)
data$points <- points_cal(formula = results$formula,rd=data)
points <- points_cal(formula = results$formula,rd=data)
points

write.table(points, file='data.csv',row.names=FALSE,col.names=FALSE,sep=',')

getwd()

library(ResourceSelection)
data1 <- read.csv("d:/data/shuju1.csv", header=TRUE, sep=",")
model <- glm(GBC~CPFC,data=data1,family=binomial(link=logit))
hl <- hoslem.test(model$y,fitted(model),g=4)
hl

library(Hmisc) 
library(rms)
library(boot)
library(caret)
library(readr)
data1 <- read.csv("d:/data/shuju1.csv", header=TRUE, sep=",")
dd1=datadist(data1)
options(datadist="dd1")
formula1<-as.formula(GBC~CPFC)
fit1 <- lrm(formula1,data=data1,x=T,y=T)
data1$predvalue <- predict(fit1)
library(pROC)
modelROC <- roc(data1$GBC,data1$predvalue)
auc(modelROC)
ci(auc(modelROC))

v<-validate(fit1,method="boot",B=1000,dxy=T)
Dxy = v[rownames(v)=="Dxy",colnames(v)=="index.corrected"]
orig_Dxy =  v[rownames(v)=="Dxy",colnames(v)=="index.orig"]
bias_corrected_c_index <- abs(Dxy)/2+0.5
orig_c_index <- abs(orig_Dxy)/2+0.5
orig_c_index
bias_corrected_c_index

library(rmda)
Data <- read.csv("d:/data/shuju1.csv", header=TRUE, sep=",")
CPFA <- decision_curve(GBC~CPFA,data = Data, family = binomial(link ='logit'),
                        thresholds= seq(0,0.9, by = 0.01),
                        confidence.intervals =0.95,study.design = 'case-control',
                        population.prevalence = 0.25)
CPFB <- decision_curve(GBC~CPFB,data = Data, family = binomial(link ='logit'),
                        thresholds= seq(0,0.9, by = 0.01),
                        confidence.intervals =0.95,study.design = 'case-control',
                        population.prevalence = 0.25)
CPFC <- decision_curve(GBC~CPFC,data = Data, family = binomial(link ='logit'),
                        thresholds= seq(0,0.9, by = 0.01),
                        confidence.intervals =0.95,study.design = 'case-control',
                        population.prevalence = 0.25)
List<- list(CPFA,CPFB,CPFC)
plot_decision_curve(List,curve.names= c('CPF-A','CPF-B','CPF-C'),
                    cost.benefit.axis =FALSE,col = c('red','blue','green'),
                    confidence.intervals =FALSE,standardize = FALSE)

plot_clinical_impact(CPFA,population.size = 1000,cost.benefit.axis = T,
                     n.cost.benefits= 8,col = c('red','blue'),
                     confidence.intervals= T)


